package exam;

//import queue.queue.Node;

interface queue{
 	public void insert(Object obj);
    public Object remove();
    public Object first();
    public int size();
    public void insertfirst(Object obj);
    public queu reverse();
    public boolean contains(Object obj);
    public String queueString();
    public void merg(queu qu);
    public void addmid(Object obj);

}

public class queu implements queue {
node head=new node();
private int size;
private class node{
	node prev,next;
	Object obj;
	node (){
		prev=this;
		next=this;
	}
	node(Object obj){
		this.obj=obj;
	}
	node(Object obj,node pr,node ne){
		this.obj=obj;
		next=ne;
		prev=pr;
	}
} // private class ended


public void insert(Object obj) {
head.prev=head.prev.next=new node(obj,head.prev,head) ;
size++;
} //insert methode

public Object remove() {
	if(size==0)
		throw new IllegalStateException("Queue Empty");
	Object last=head.prev.obj;
	head.next=head.next.next;
	size--;
	return last;
}

public Object first() {
	if(size==0)
		throw new IllegalStateException("Queue is Empty");
	return head.next.obj;
}

public void insertfirst(Object obj) {
	head.next=new node(obj,head,head.next);
	size++;
}
public Object removelast() {
	if(size==0)
		throw new IllegalStateException("Queue is empty");
	Object last=head.prev.obj;
	head.prev=head.prev.prev;
	size--;
	return last;
}
public void addmid(Object obj) {
	int half=size/2;
	int i=0;
	for(node p=head.next;p!=head;p=head.next) {
		i++;
		if(i==half) {
		 p.next=new node(obj,p,p.next);
		 size++;
		 break;
		}
	}
}

public int size() {
	return size;
}
public void merg(queu qu) {
this.head.prev.next=qu.head.next;
qu.head.next.prev=this.head.prev;
qu.head.prev.next=this.head;
this.head.prev=qu.head.prev.next;
for(node p=qu.head.next; p!=head.prev;p=p.next) {
	size++;
}
}
	//return p;


public String queueString() {
	String str="";
	int i=0;
	node p;
	for(p=this.head.next;p!=head.prev;p=p.next) {
		str+=p.obj+"\n";
	}
	return str;
}
public void display() {
	for(node p = head.prev; p != head; p = p.prev) {
		System.out.println(p.obj);
	}
}
public boolean contains(Object object){
    for(node p = head.next; p != head; p = p.next){
        if(p.obj == object){
            return true;
        }
    }
    return false;
}

public boolean isempty() {
	return (size==0);
}

public queu reverse() {
	queu qu=new queu ();
	for(node p=head.prev;p!= head;p= p.prev) {
		qu.insert(p.obj);
	}
	return qu;
}



public Object last() {
	if(size==0)
		throw new IllegalStateException("Queue is empty");
	return head.prev.obj;
}

public static void main(String arg[]) {
	queu queue=new queu();
	queue.insert("amaar");
	queue.insert("kashif");
	queue.insert("kashmore");
	queue.insert("Khalique");
//	queu q=new queu();
//	q.insert(1);
//	q.insert(2);
//	q.insert(3);
//     q.insert("Khuram");	
//
//     queue.merg(q);
//    queu queue2 = queue.reverse();
    queue.display();
//System.out.println(queue2.queueString());
	System.out.println("Size of the Queue is "+queue.size());
	System.out.println(queue.contains("kashif"));
}




}
